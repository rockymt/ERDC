function [F_ext]=Force_ext(N,Tim)

  Force=Tim*600;
  F_ext=zeros(4*N+3,1);
  F_ext(dof_i(N+1,3))=Force;

end