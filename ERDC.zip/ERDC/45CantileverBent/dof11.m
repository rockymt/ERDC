function [dofnum]=dof11(i,j)
dofnum=(i-2)*4+j;
end