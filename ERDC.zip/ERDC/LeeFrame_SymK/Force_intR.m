function [F_int]=Force_intR(N,ti,d1i,li,kap1_ii0,kap2_ii0,tau_ii0,li0,p,q,r)
global EI1 EI2 GIp EA ;

F_int=zeros(4*N+3,1);

Dui_p=[zeros(3,3) zeros(3,1) -eye(3) zeros(3,1) eye(3)];
Dui_m=[-eye(3) zeros(3,1) eye(3) zeros(3,1) zeros(3,3)];

T1R=[eye(3) li0/2*li(1)*screw(ti(:,1)) -li0/2*ti(:,1) zeros(3,4);
    zeros(1,3) ti(:,1)' zeros(1,5);
    eye(3) -li0/2*li(1)*screw(ti(:,1))  li0/2*ti(:,1) zeros(3,4);
    zeros(1,7) 1 zeros(1,3);
    zeros(3,8) eye(3)];
TNR=[eye(3) zeros(3,8);
    zeros(1,3) 1 zeros(1,7);
    zeros(3,4) -li0/2*ti(:,N)  li0/2*li(N)*screw(ti(:,N)) eye(3);
    zeros(1,5) ti(:,N)' zeros(1,3);
    zeros(3,4)  li0/2*ti(:,N) -li0/2*li(N)*screw(ti(:,N)) eye(3)];
T2R=[eye(3) -li0/2*li(1)*screw(ti(:,1))  li0/2*ti(:,1) zeros(3,8);
    zeros(8,7) eye(8)];
TNm1R=[eye(8) zeros(8,7);
    zeros(3,8) -li0/2*ti(:,N)  li0/2*li(N)*screw(ti(:,N)) eye(3)];

Dui_p=Dui_p/li0;
Dui_m=Dui_m/li0;
phii_p=[zeros(1,3) 0 zeros(1,3) 1 zeros(1,3)];
phii_m=[zeros(1,3) 1 zeros(1,3) 0 zeros(1,3)];

for i=2:N
    dof11_i=dof11(i,1:11);
    
    li_p=li(i);
    li_m=li(i-1);
    
    ti_p=ti(:,i);
    ti_m=ti(:,i-1);
    
    d1i_p=d1i(:,i);
    d1i_m=d1i(:,i-1);
    
    d2i_p=cross(ti_p,d1i_p);
    d2i_m=cross(ti_m,d1i_m);
    
    kap1_iSt=(dot(ti_m,d2i_p)-dot(ti_p,d2i_m))/2/li0;
    kap2_iSt=(-dot(ti_m,d1i_p)+dot(ti_p,d1i_m))/2/li0;
    tau_iSt=(-dot(d1i_m,d2i_p)+dot(d1i_p,d2i_m))/2/li0;
    
    La=p+q*(dot(ti_m,ti_p)+dot(d1i_m,d1i_p)+dot(d2i_m,d2i_p));
    
    kap1_i0=kap1_ii0(i);
    kap2_i0=kap2_ii0(i);
    tau_i0=tau_ii0(i);
    
    Pti_p=eye(3)-ti_p*ti_p';
    Pti_m=eye(3)-ti_m*ti_m';
    VarIvLa=-1/La^2*q*((dot(d2i_m,d1i_p)-dot(d1i_m,d2i_p))*phii_m ...
        +(dot(d2i_p,d1i_m)-dot(d1i_p,d2i_m))*phii_p ...
        +(ti_p'*Pti_m-dot(d1i_p,ti_m)*d1i_m'-dot(d2i_p,ti_m)*d2i_m')*Dui_m/li_m ...
        +(ti_m'*Pti_p-dot(d1i_m,ti_p)*d1i_p'-dot(d2i_m,ti_p)*d2i_p')*Dui_p/li_p);
    
    %%%%%%%%%%%%%%%%%%%% 1-bending  %%%%%%%%%%%%%%%%%%%%%%%%%%
    B1_p1=-dot(ti_m,ti_p)*d2i_p'*Dui_p/li_p;
    B1_p2=d2i_p'*Pti_m*Dui_m/li_m;
    B1_p3=-d1i_p'*ti_m*phii_p;
    
    B1_m1=-dot(ti_p,ti_m)*d2i_m'*Dui_m/li_m;
    B1_m2=d2i_m'*Pti_p*Dui_p/li_p;
    B1_m3=-d1i_m'*ti_p*phii_m;
    
    B1_St=((B1_p1+B1_p2+B1_p3)-(B1_m1+B1_m2+B1_m3))/2/li0;
    B1=B1_St*(1/La+r)+kap1_iSt*VarIvLa;
    
    Mb1i=EI1*(kap1_iSt*(1/La+r)-kap1_i0);
    F_intb1=(B1'*Mb1i)*li0;
    
    %%%%%%%%%%%%%%%%%%%% 2-bending  %%%%%%%%%%%%%%%%%%%%%%%%%%
    B2_p1=dot(ti_m,ti_p)*d1i_p'*Dui_p/li_p;
    B2_p2=-d1i_p'*Pti_m*Dui_m/li_m;
    B2_p3=-d2i_p'*ti_m*phii_p;
    
    B2_m1=dot(ti_p,ti_m)*d1i_m'*Dui_m/li_m;
    B2_m2=-d1i_m'*Pti_p*Dui_p/li_p;
    B2_m3=-d2i_m'*ti_p*phii_m;
    
    B2_St=((B2_p1+B2_p2+B2_p3)-(B2_m1+B2_m2+B2_m3))/2/li0;
    
    B2=B2_St*(1/La+r)+kap2_iSt*VarIvLa;
    
    Mb2i=EI2*(kap2_iSt*(1/La+r)-kap2_i0);
    F_intb2=(B2'*Mb2i)*li0;
    
    %%%%%%%%%%%%%%%%%%%% 3-twisting  %%%%%%%%%%%%%%%%%%%%%%%%%%
    B3_p1=dot(d1i_m,d1i_p)*phii_p;
    B3_p2=-dot(d2i_m,d2i_p)*phii_m;
    B3_p3=dot(d2i_p,ti_m)*d1i_m'*Dui_m/li_m;
    B3_p4=dot(d1i_m,ti_p)*d2i_p'*Dui_p/li_p;
    
    B3_m1=dot(d1i_p,d1i_m)*phii_m;
    B3_m2=-dot(d2i_p,d2i_m)*phii_p;
    B3_m3=dot(d2i_m,ti_p)*d1i_p'*Dui_p/li_p;
    B3_m4=dot(d1i_p,ti_m)*d2i_m'*Dui_m/li_m;
    
    B3_St=((B3_p1+B3_p2+B3_p3+B3_p4)-(B3_m1+B3_m2+B3_m3+B3_m4))/2/li0;
    B3=B3_St*(1/La+r)+tau_iSt*VarIvLa;
    
    Mti=GIp*(tau_iSt*(1/La+r)-tau_i0);
    F_intt=(B3'*Mti)*li0;
    
    %%%%%%%%%%%%%%%%%%%% streching  %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Bs_p=li_p*ti_p'*Dui_p;
    Ni_p=EA*(li_p^2-1)/2;
    Bs_m=li_m*ti_m'*Dui_m;
    Ni_m=EA*(li_m^2-1)/2;
    
    F_ints=(Bs_p'*Ni_p+Bs_m'*Ni_m)*li0/2;
    
    %%%%%%%%%%%%%%%%%%%%     sum   %%%%%%%%%%%%%%%%%%%%%%%%%%
    F_int_=F_intb1+F_intb2+F_intt+F_ints;
    
    if i==2
        F_int(dof11_i)=F_int(dof11_i)+T1R'*F_int_;
    elseif i==3
        dof15_i=1:15;
        F_int(dof15_i)=F_int(dof15_i)+T2R'*F_int_;
    elseif i==N-1
        dof15_i=4*N-11:4*N+3;
        F_int(dof15_i)=F_int(dof15_i)+TNm1R'*F_int_;
    elseif i==N
        F_int(dof11_i)=F_int(dof11_i)+TNR'*F_int_;
    else
        F_int(dof11_i)=F_int(dof11_i)+F_int_;
    end
end

end