%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program uses the function "assem.m" in Calfem from Lund Institute of Technology
% Download it from website: https://github.com/CALFEM/calfem-matlab/tree/master/fem
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
global EI1 EI2 GIp EA ToltalLen TotalForce;

p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;

N=10;
loadnum=1.5+(N-1)/5;
loadfnum=floor(loadnum);
loadbnum=loadfnum+1;

Edof=[1 1:4*N+3;
      2 4*N+1:4*N+3 4*N-2:4*N 4*N+4:8*N];

EE=7.2E6;
BB=3.0; HH=2.0;
I1=BB*HH^3/12;
I2=HH*BB^3/12;
EI1=EE*I1;
EI2=EE*I2;
GIp=(EI1+EI2)/(1+0.3)/2;
EA=EE*BB*HH;
ToltalLen=120;
TotalForce=35000;

[li0{1},kap1i_0{1},kap2i_0{1},taui_0{1}]=shape_free1(N);
[X{1},ti{1},d1i{1},li{1}]=shape_ini1(N,li0{1});
[li0{2},kap1i_0{2},kap2i_0{2},taui_0{2}]=shape_free2(N);
[X{2},ti{2},d1i{2},li{2}]=shape_ini2(N,li0{2});

Tim=0.02; MaxIter=100; Tol=1e-8; MaxSteps=5000; FinalTim=1.0;
SnapNumCrt=300;
SnapNum=0;
Idesire=3;
DTim=Tim; 

Xstart=X{2}(dof_i(loadfnum,1))*(loadbnum-loadnum)+X{2}(dof_i(loadbnum,1))*(loadnum-loadfnum);
Ystart=X{2}(dof_i(loadfnum,2))*(loadbnum-loadnum)+X{2}(dof_i(loadbnum,2))*(loadnum-loadfnum);
ustart=[0];
vend=[0];
TimRc=[0];

figure(10)
plot(X{1}(dof_i(1:N+1,1)),X{1}(dof_i(1:N+1,2)),'--');
hold on
plot(X{2}(dof_i(1:N+1,1)),X{2}(dof_i(1:N+1,2)),'--');
axis equal;
axis([-25,160,-150,10])

FinalFlag=0;

for Step=1:MaxSteps

    tip=ti; lip=li;
    if Step == 1
        [F_extR]= Force_extR(N,Tim);
        [UR,idxf]=BoundaryR(N);
        KR=zeros(8*N,8*N);
        F_intR=0*F_extR;
        [F_intRe{1}, KRe{1}]=Force_int_KR_Ksym(N,ti{1},d1i{1},li{1},kap1i_0{1},kap2i_0{1},taui_0{1},li0{1},p,q,r);
        [KR,F_intR]=assem(Edof(1,:),KR,KRe{1},F_intR,F_intRe{1});
        [F_intRe{2}, KRe{2}]=Force_int_KR_Ksym(N,ti{2},d1i{2},li{2},kap1i_0{2},kap2i_0{2},taui_0{2},li0{2},p,q,r);
        [KR,F_intR]=assem(Edof(2,:),KR,KRe{2},F_intR,F_intRe{2});
        RHS=F_extR-F_intR-KR*UR;

        [LK,UK]=lu(KR(idxf,idxf));
        URf=LK\RHS(idxf);
        URf=UK\URf;

        DURf1=URf;
        DTim1=Tim;
    else
        DURf1=factor*DURfprev;
        DTim1=factor*DTimprev;
        if Tim+DTim1>=FinalTim
            DTim1=FinalTim-Tim;
            FinalFlag=1;
        end
        Tim=Tim+DTim1;
        
    end 
    UR(idxf)=DURf1;
    URe{1}=extract(Edof(1,:),UR);
    URe{2}=extract(Edof(2,:),UR);
    U{1}=DispR2N(URe{1}',N,ti{1},li{1},li0{1});
    U{2}=DispR2N(URe{2}',N,ti{2},li{2},li0{2});
    X{1}=X{1}+U{1};
    X{2}=X{2}+U{2};
    
    [ti{1}, d1i{1},li{1}]=Update_everything(N,X{1},U{1},ti{1},d1i{1},li0{1});
    [ti{2}, d1i{2},li{2}]=Update_everything(N,X{2},U{2},ti{2},d1i{2},li0{2});    
    UR=UR*0;
    DUR= DURf1;
    DTim=DTim1;
    
    for Ipre=1:MaxIter
        [F_extR]= Force_extR(N,Tim);
        KR=zeros(8*N,8*N);
        F_intR=0*F_extR;
        [F_intRe{1}, KRe{1}]=Force_int_KR_Ksym(N,ti{1},d1i{1},li{1},kap1i_0{1},kap2i_0{1},taui_0{1},li0{1},p,q,r);
        [KR,F_intR]=assem(Edof(1,:),KR,KRe{1},F_intR,F_intRe{1});
        [F_intRe{2}, KRe{2}]=Force_int_KR_Ksym(N,ti{2},d1i{2},li{2},kap1i_0{2},kap2i_0{2},taui_0{2},li0{2},p,q,r);
        [KR,F_intR]=assem(Edof(2,:),KR,KRe{2},F_intR,F_intRe{2});

        if Step == 1 || Ipre~=1
            RHS=F_extR-F_intR;
        else
            RHS=F_extR-F_intR-KR*UR;
        end

        [DF_ext]= DForce_ext(N);

        [LK,UK]=lu(KR(idxf,idxf));
        URf1=LK\DF_ext(idxf);
        URf1=UK\URf1;
        URf2=LK\RHS(idxf);
        URf2=UK\URf2;

        DDTim = -dot(DURf1,URf2)/dot(DURf1,URf1);
        DURf   = DDTim*URf1 + URf2;
        
        DTim=DTim +DDTim;
        Tim=Tim +DDTim;
        
        UR(idxf)=UR(idxf)+DURf;
        DUR=DUR+DURf;
        URe{1}=extract(Edof(1,:),UR);
        URe{2}=extract(Edof(2,:),UR);
        U{1}=DispR2N(URe{1}',N,ti{1},li{1},li0{1});
        U{2}=DispR2N(URe{2}',N,ti{2},li{2},li0{2});
        X{1}=X{1}+U{1};
        X{2}=X{2}+U{2};
         
        [ti{1}, d1i{1},li{1}]=Update_everything(N,X{1},U{1},ti{1},d1i{1},li0{1});
        [ti{2}, d1i{2},li{2}]=Update_everything(N,X{2},U{2},ti{2},d1i{2},li0{2});
        
        if Ipre==1
            error1=norm(RHS(idxf));
%             error1=abs(dot(RHS(idxf),URf));
%             error1=norm(URf);
        else
            errormsg=norm(RHS(idxf))/error1; %Force criteria
%             errormsg=abs(dot(RHS(idxf),URf))/error1; %Energy criteria
%             errormsg=norm(URf)/error1; %displacement criteria
            if  errormsg<Tol
%                 endmoment=[endmoment F_intR(4:6)];
                ustart=[ustart X{2}(dof_i(loadfnum,1))*(loadbnum-loadnum)+X{2}(dof_i(loadbnum,1))*(loadnum-loadfnum)-Xstart];
                vend=[vend X{2}(dof_i(loadfnum,2))*(loadbnum-loadnum)+X{2}(dof_i(loadbnum,2))*(loadnum-loadfnum)-Ystart];
                TimRc=[TimRc Tim];
                break;
            end
        end
        UR=UR*0;
    end
    if Ipre==MaxIter
        Step
        Ipre
        error('Newton-Raphson iterations did not converge!');
    end
    factor=sqrt(Idesire/Ipre);
    DURfprev=DUR;
    DTimprev=DTim;
    SnapNum=SnapNum+1;
    if SnapNum>SnapNumCrt  || FinalFlag==1
        SnapNum=0;
        disp('=================================');
        disp([' Load step :',num2str(Step),'  Tim:',num2str(Tim),'  DTim:',num2str(DTim)]);
        disp('=================================');
        disp('  NR iter : L2-norm residual')
        disp(['  Iter ',num2str(Ipre),' RHS error:',num2str(errormsg)]);
        
        if FinalFlag==1
            break;
        end
        figure(10)
        plot(X{1}(dof_i(1:N+1,1)),X{1}(dof_i(1:N+1,2)),'-');
        plot(X{2}(dof_i(1:N+1,1)),X{2}(dof_i(1:N+1,2)),'-');
        forcestr=[num2str(round(35000*Tim))];
        text(X{1}(dof_i(N-5,1)),X{1}(dof_i(N-5,2)),forcestr);
    end
end

figfile=['configure'];
print (10,"-r1000", [figfile,'.tiff']); 
%saveas(10,[figfile,'.tiff']);
saveas(10,[figfile,'.png']);
% saveas(10,[figfile,'.eps']);
print(10,[figfile,'.eps'],'-depsc');

figure(12)
plot(ustart/ToltalLen,TimRc*TotalForce/EI1*ToltalLen^2, '-',-vend/ToltalLen,TimRc*TotalForce/EI1*ToltalLen^2,'--')
