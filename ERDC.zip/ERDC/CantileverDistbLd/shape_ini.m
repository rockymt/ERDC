function [X,tip,d1ip,li]=shape_ini(N,li0)
global ToltalLen;

mm=N/2;
seg=1/(mm-0.5);
s=ToltalLen/2*[0:seg:1-seg/2 1];
lastSegLen=s(end)-s(end-1);
s(end)=s(end)+lastSegLen;
xx=[fliplr(-(s(2:end))) s]+ToltalLen/2;
yy=0*xx;
zz=yy;

X=[xx;yy;zz];

lli=zeros(1,N);
li=lli;
tip=zeros(3,N);
d1ip=zeros(3,N);

for ii=1:N
    dX=X(:,ii+1)-X(:,ii);
    lli(ii)=sqrt(dot(dX,dX));
    tip(:,ii)=dX/lli(ii);
    li(ii)=lli(ii)/li0;
end
X(:,1)=(X(:,1)+X(:,2))/2;
X(:,N+1)=(X(:,N)+X(:,N+1))/2;
theta=0*X(1,:);
X=[X;theta];
X=X(:);
X(end)=[];

d1ip(:,1)=[0;0;1];

for ii=2:N
    d1ip(:,ii)=para_base(tip(:,ii-1),tip(:,ii),d1ip(:,ii-1));
    d1ip(:,ii)=d1ip(:,ii)/norm(d1ip(:,ii));
end

end