function [U]=DispR2N(UR,N,ti,li,li0)
% Transform the displacement with rotation end to normal(non rotation) 
U=UR;
T1R=[zeros(1,3) ti(:,1)' zeros(1,5);
    eye(3) -li0/2*li(1)*screw(ti(:,1))  li0/2*ti(:,1) zeros(3,4)];
TNR=[zeros(3,4) -li0/2*ti(:,N)  li0/2*li(N)*screw(ti(:,N)) eye(3);
    zeros(1,5) ti(:,N)' zeros(1,3)];
U(4:7)=T1R*UR(1:11);
U(end-6:end-3)=TNR*UR(end-10:end);
end