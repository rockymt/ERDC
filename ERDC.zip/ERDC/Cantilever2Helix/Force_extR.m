function [F_ext]=Force_extR(N,Tim)
  Moment=[10*Tim; 0; 10*Tim];
  F_ext=zeros(4*N+3,1);
  F_ext(end-5:end-3)=Moment;
end