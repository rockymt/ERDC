function [URp,idxf]=BoundaryR(N,Dtim)%Tim
% URp is displacements vector with constraint DOFs
% idxf is index of free DOFs
% BC(:,2) are the displacements in "R" function;
  theta=pi*Dtim;
  BC=[1 0
      2 0
      3 0
      4 theta
      5 0
      6 0
      4*N-2 -theta
      4*N-1 0
      4*N 0
      ];
  [URp,idxf]=Form_up(N,BC);
end
function [URp,idxf]=Form_up(N,bc)
URp=zeros(8*N-6,1);
URp(bc(:,1))=bc(:,2);
idxf=1:8*N-6;
idxf(bc(:,1))=[];
end
