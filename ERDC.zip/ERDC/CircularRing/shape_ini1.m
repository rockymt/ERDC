function [X,tip,d1ip,li]=shape_ini1(N,li0)
  global RR
  n=N-1;
  r1=pi*RR/2/n/tan(pi/2/n)-1i*(pi*RR/2/n);
  r=r1*exp(1i*pi/n*(0:N));
  r(1)=(r(1)+r(2))/2;
  r(end)=(r(end)+r(end-1))/2;
  xx=real(r);
  yy=imag(r);
  zz=0*xx;
  X=[xx;yy;zz];
  
  lli=zeros(1,N);
  li=lli;
  tip=zeros(3,N);
  d1ip=zeros(3,N);

  for ii=1:N
    dX=X(:,ii+1)-X(:,ii);
    lli(ii)=sqrt(dot(dX,dX));
    tip(:,ii)=dX/lli(ii);
    li(ii)=lli(ii)/li0;
  end
  li(1)=li(1)*2;
  li(end)=li(end)*2;
  theta=0*X(1,:);
  X=[X;theta];
  X=X(:);
  X(end)=[];
  
  d1ip(:,1)=[-1;0;0];
  
  for ii=2:N
      d1ip(:,ii)=para_base(tip(:,ii-1),tip(:,ii),d1ip(:,ii-1));
      d1ip(:,ii)=d1ip(:,ii)/norm(d1ip(:,ii));
  end

end