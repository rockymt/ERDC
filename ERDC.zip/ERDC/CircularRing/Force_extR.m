function [F_ext]=Force_extR(N)
  F_ext=zeros(8*N-6,1);
end