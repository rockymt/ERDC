%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program uses the function "assem.m" in Calfem from Lund Institute of Technology
% Download it from website: https://github.com/CALFEM/calfem-matlab/tree/master/fem
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
global EI1 EI2 GIp EA ToltalLen RR BB HH;
p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;
N=50;

Edof=[1 1:4*N+3;
      2 4*N+1:4*N+3 4*N-2:4*N 4*N+4:8*N-6 4:6 1:3];

RR=20.0;
EE=21E6;
BB=1.0/3; HH=1.0;%
I1=BB*HH^3/12;
I2=HH*BB^3/12;
EI1=EE*I1;
EI2=EE*I2;

% GIp=(EI1+EI2)/(1+0.3)/2;
GIp=EE/2/(1+0.3)*9.753e-3;
ToltalLen=20*pi;

EA=EE*BB*HH;

[li0{1},kap1i_0{1},kap2i_0{1},taui_0{1}]=shape_free1(N,p,q,r);
[X{1},ti{1},d1i{1},li{1}]=shape_ini1(N,li0{1});
[li0{2},kap1i_0{2},kap2i_0{2},taui_0{2}]=shape_free2(N,p,q,r);
[X{2},ti{2},d1i{2},li{2}]=shape_ini2(N,li0{2});

Tim=0; MaxIter=50; Tol=1e-8; Steps=180; FinalTim=1.0; 
Dtim=FinalTim/Steps; NoSnap=20; SnapInc=Steps/NoSnap;
file=['ele1_',num2str(Tim*100),'.vtu'];
write_grid(X{1},ti{1},d1i{1},file,N);
file=['ele2_',num2str(Tim*100),'.vtu'];
write_grid(X{2},ti{2},d1i{2},file,N);

endmoment=[0;0;0];

for ii=1:Steps
    Tim=Tim+Dtim;

    [F_extR]= Force_extR(N);
    [UR,idxf]=BoundaryR(N,Dtim);

    for jj=1:MaxIter
        KR=zeros(8*N-6,8*N-6);
        F_intR=0*F_extR;
        [F_intRe{1}, KRe{1}]=Force_int_KR(N,ti{1},d1i{1},li{1},kap1i_0{1},kap2i_0{1},taui_0{1},li0{1},p,q,r);
        [KR,F_intR]=assem(Edof(1,:),KR,KRe{1},F_intR,F_intRe{1});
        [F_intRe{2}, KRe{2}]=Force_int_KR(N,ti{2},d1i{2},li{2},kap1i_0{2},kap2i_0{2},taui_0{2},li0{2},p,q,r);
        [KR,F_intR]=assem(Edof(2,:),KR,KRe{2},F_intR,F_intRe{2});
        if jj==1
            RHS=F_extR-F_intR-KR*UR;
        else
            RHS=F_extR-F_intR;
        end

        [LK,UK]=lu(KR(idxf,idxf));
        URf=LK\RHS(idxf);
        URf=UK\URf;

        UR(idxf)=URf; 
        URe{1}=extract(Edof(1,:),UR);
        URe{2}=extract(Edof(2,:),UR);
        U{1}=DispR2N(URe{1}',N,ti{1},li{1},li0{1});
        U{2}=DispR2N(URe{2}',N,ti{2},li{2},li0{2});
        X{1}=X{1}+U{1};
        X{2}=X{2}+U{2};
           
        [ti{1}, d1i{1},li{1}]=Update_everything(N,X{1},U{1},ti{1},d1i{1},li0{1});
        [ti{2}, d1i{2},li{2}]=Update_everything(N,X{2},U{2},ti{2},d1i{2},li0{2});
        
        if jj==1
%             error1=norm(RHS(idxf));
            error1=abs(dot(RHS(idxf),URf));
%             error1=norm(URf);
        else
%             errormsg=norm(RHS(idxf))/error1; %Force criteria
            errormsg=abs(dot(RHS(idxf),URf))/error1; %Energy criteria
%             errormsg=norm(URf)/error1; %displacement criteria
            if  errormsg<Tol
                endmoment=[endmoment F_intR(4:6)];
                break;
            end
        end
        UR=UR*0;
    end
    if jj==MaxIter
        ii
        jj
        error('Newton-Raphson iterations did not converge!');
    end
    if mod(ii,SnapInc)==0
        disp('=================================')
        disp([' Load step :',num2str(ii),'  Tim:',num2str(Tim)])
        disp('=================================')
        disp('  NR iter : L2-norm residual')
        disp(['  Iter ',num2str(jj),' RHS error:',num2str(errormsg)]);

        figfile=['shape_',num2str(Tim)];
        figure(10)
        set(10,'visible','off');
        plot3(X{1}(dof_i(1:N+1,1)),X{1}(dof_i(1:N+1,2)),X{1}(dof_i(1:N+1,3)),'r-');
        hold on
        plot3(X{2}(dof_i(1:N+1,1)),X{2}(dof_i(1:N+1,2)),X{2}(dof_i(1:N+1,3)),'r-');
        hold off
        axis([-30 30 -30 30 -30 30])
        title(['time ', num2str(Tim)]);
        saveas(10,[figfile,'.jpg']);

        file=['ele1_',num2str(Tim*100),'.vtu'];
        write_grid(X{1},ti{1},d1i{1},file,N);
        file=['ele2_',num2str(Tim*100),'.vtu'];
        write_grid(X{2},ti{2},d1i{2},file,N);
    end
end
save('endmoment.txt','endmoment','-ascii','-double');

