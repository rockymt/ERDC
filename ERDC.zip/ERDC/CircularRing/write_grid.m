function [err]=write_grid(X,ti,d1i,file,N)
global BB HH

err=0;

Coord=zeros(3,4*N);

d2i=cross(ti(:,1),d1i(:,1));
Xc=X(dof_i(1,1:3));
Coord(:,1)=Xc+BB/2*d1i(:,1)+HH/2*d2i;
Coord(:,2)=Xc-BB/2*d1i(:,1)+HH/2*d2i;
Coord(:,3)=Xc-BB/2*d1i(:,1)-HH/2*d2i;
Coord(:,4)=Xc+BB/2*d1i(:,1)-HH/2*d2i;
for ii=2:N-1
    d2i=cross(ti(:,ii),d1i(:,ii));
    Xc=(X(dof_i(ii,1:3))+X(dof_i(ii+1,1:3)))/2;
    Coord(:,4*ii-3)=Xc+BB/2*d1i(:,ii)+HH/2*d2i;
    Coord(:,4*ii-2)=Xc-BB/2*d1i(:,ii)+HH/2*d2i;
    Coord(:,4*ii-1)=Xc-BB/2*d1i(:,ii)-HH/2*d2i;
    Coord(:,4*ii)=Xc+BB/2*d1i(:,ii)-HH/2*d2i;
end
d2i=cross(ti(:,N),d1i(:,N));
Xc=X(dof_i(N+1,1:3));
Coord(:,4*N-3)=Xc+BB/2*d1i(:,N)+HH/2*d2i;
Coord(:,4*N-2)=Xc-BB/2*d1i(:,N)+HH/2*d2i;
Coord(:,4*N-1)=Xc-BB/2*d1i(:,N)-HH/2*d2i;
Coord(:,4*N)=Xc+BB/2*d1i(:,N)-HH/2*d2i;

El1=zeros(8,N-1);
for ii=2:N
    El1(:,ii-1)=4*ii-(8:-1:1);
end

NPt=size(Coord,2);
NEl1=size(El1,2);


fid=fopen(file,'w');
fprintf(fid,'<?xml version="1.0"?>\n');
fprintf(fid,'<VTKFile type="UnstructuredGrid" version="0.1" byte_order="LittleEndian">\n');
fprintf(fid,'<UnstructuredGrid>\n');


fprintf(fid,'<Piece NumberOfPoints="%d" NumberOfCells="%d">\n',NPt,NEl1);

fprintf(fid,'<PointData>\n');

fprintf(fid,'</PointData>\n');

fprintf(fid,'<CellData>\n');
fprintf(fid,'</CellData>\n');

fprintf(fid,'<Points>\n');
fprintf(fid,'<DataArray type="Float64" Name="Points" NumberOfComponents="3" format="ascii">\n');
fprintf(fid,'%20.12e %20.12e %20.12e\n',Coord);
fprintf(fid,'</DataArray>\n');
fprintf(fid,'</Points>\n');

fprintf(fid,'<Cells>\n');
fprintf(fid,'<DataArray type="Int64" Name="connectivity" format="ascii">\n');
fprintf(fid,'%8d %8d %8d %8d %8d %8d %8d %8d\n',El1);
fprintf(fid,'</DataArray>\n');

fprintf(fid,'<DataArray type="Int64" Name="offsets" format="ascii">\n');
fprintf(fid,'%d\n',8:8:8*NEl1);
fprintf(fid,'</DataArray>\n');

fprintf(fid,'<DataArray type="UInt8" Name="types" format="ascii" RangeMin="9" RangeMax="25">\n');
fprintf(fid,'%d\n',12*ones(1,NEl1));
fprintf(fid,'</DataArray>\n');

fprintf(fid,'</Cells>\n');

fprintf(fid,'</Piece>\n');
fprintf(fid,'</UnstructuredGrid>\n');
fprintf(fid,'</VTKFile>\n');
fclose(fid);
