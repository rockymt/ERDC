function [li0,kap1i_0,kap2i_0,taui_0]=shape_free1(N,p,q,rr)
  global RR
  n=N-1;
  r1=pi*RR/2/n/tan(pi/2/n)-1i*(pi*RR/2/n);
  r=r1*exp(1i*pi/n*(0:N));
  r(1)=(r(1)+r(2))/2;
  r(end)=(r(end)+r(end-1))/2;
  xx=real(r);
  yy=imag(r);
  zz=0*xx;
  X0=[xx;yy;zz];
  ti0=zeros(3,N);

  kap1i_0=-0*ones(1,N+1);
  kap2i_0=-0*ones(1,N+1);
  taui_0=-0*ones(1,N+1);
  
  for ii=1:N
    dX=X0(:,ii+1)-X0(:,ii);
    li0=sqrt(dot(dX,dX));
    ti0(:,ii)=dX/li0;
  end
  li0=li0*2;
  
  d1i0(:,1)=[-1;0;0];

  for ii=2:N
      d1i0(:,ii)=para_base(ti0(:,ii-1),ti0(:,ii),d1i0(:,ii-1));
      d1i0(:,ii)=d1i0(:,ii)/norm(d1i0(:,ii));
  end
  
  for ii=2:N  
    ti_p=ti0(:,ii);
    ti_m=ti0(:,ii-1);
    
    d1i_p=d1i0(:,ii);
    d1i_m=d1i0(:,ii-1);

    d2i_p=cross(ti_p,d1i_p);
    d2i_m=cross(ti_m,d1i_m);
    
    La=p+q*(dot(ti_m,ti_p)+dot(d1i_m,d1i_p)+dot(d2i_m,d2i_p));
    
    kap1i_0(ii)=(dot(ti_m,d2i_p)-dot(ti_p,d2i_m))/2/li0*(1/La+rr);
    
    kap2i_0(ii)=(-dot(ti_m,d1i_p)+dot(ti_p,d1i_m))/2/li0*(1/La+rr);
    
    taui_0(ii)=(-dot(d1i_m,d2i_p)+dot(d1i_p,d2i_m))/2/li0*(1/La+rr);
  end
  
end