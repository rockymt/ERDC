function [X,tip,d1ip,li]=shape_ini(N,li0,X0)

  X=X0;
  
  lli=zeros(1,N);
  li=lli;
  tip=zeros(3,N);
  d1ip=zeros(3,N);

  for ii=1:N
    dX=X(:,ii+1)-X(:,ii);
    lli(ii)=sqrt(dot(dX,dX));
    tip(:,ii)=dX/lli(ii);
    li(ii)=lli(ii)/li0(ii);
  end
  li(1)=li(1)*2;
  li(end)=li(end)*2;
  theta=0*X(1,:);
  X=[X;theta];
  X=X(:);
  X(end)=[];
  
  d1ip(:,1)=[0;1;0];
  d2ip=cross(tip(:,1),d1ip(:,1));
  d2ip=d2ip/norm(d2ip);
  d1ip(:,1)=cross(d2ip,tip(:,1));

  for ii=2:N
      d1ip(:,ii)=para_base(tip(:,ii-1),tip(:,ii),d1ip(:,ii-1));
      d1ip(:,ii)=d1ip(:,ii)/norm(d1ip(:,ii));
  end


