function [F_ext]=Force_ext(N,Tim)

  Force=[0; 0; 0.2]*Tim;
  F_ext=zeros(4*N+3,1);
  
  F_ext(end-2:end)=Force;
end