function [li0,kap1i_0,kap2i_0,taui_0,X0]=shape_free(N,p,q,rr)
global ToltalLen

  R0=ToltalLen/(6*sqrt((0.75*pi)^2+1)+27*pi^2/8*log(4/3/pi+sqrt(1+(4/3/pi)^2)));
  
  n=N-1;
  beta=(0:2*n)/n/2*9*pi;
  beta(3:2:2*N-3)=[];
  xx=R0*sin(beta);
  yy=R0*(cos(beta)-1);
  zz=R0*6/81/pi^2*beta.^2;
  
  X0=[xx;yy;zz];
  ti0=zeros(3,N);

  kap1i_0=-0*ones(1,N+1);
  kap2i_0=-0*ones(1,N+1);
  taui_0=-0*ones(1,N+1);
  li0=zeros(N,1);
  for ii=1:N
    dX=X0(:,ii+1)-X0(:,ii);
    li0(ii)=sqrt(dot(dX,dX));
    ti0(:,ii)=dX/li0(ii);
  end
  li0(1)=2*li0(1); 
  li0(N)=2*li0(N);
  
  d1i0(:,1)=[0;1;0];
  d2i0=cross(ti0(:,1),d1i0(:,1));
  d2i0=d2i0/norm(d2i0);
  d1i0(:,1)=cross(d2i0,ti0(:,1));

  for ii=2:N
      d1i0(:,ii)=para_base(ti0(:,ii-1),ti0(:,ii),d1i0(:,ii-1));
      d1i0(:,ii)=d1i0(:,ii)/norm(d1i0(:,ii));
  end
  
  for ii=2:N  
    ti_p=ti0(:,ii);
    ti_m=ti0(:,ii-1);
    
    d1i_p=d1i0(:,ii);
    d1i_m=d1i0(:,ii-1);

    d2i_p=cross(ti_p,d1i_p);
    d2i_m=cross(ti_m,d1i_m);
    La=p+q*(dot(ti_m,ti_p)+dot(d1i_m,d1i_p)+dot(d2i_m,d2i_p));
    li0_p=li0(ii); 
    li0_m=li0(ii-1);
    l_i0=(li0_p+li0_m)/2;
    
    kap1i_0(ii)=(dot(ti_m,d2i_p)-dot(ti_p,d2i_m))/2/l_i0*(1/La+rr);
    
    kap2i_0(ii)=(-dot(ti_m,d1i_p)+dot(ti_p,d1i_m))/2/l_i0*(1/La+rr);
    
    taui_0(ii)=(-dot(d1i_m,d2i_p)+dot(d1i_p,d2i_m))/2/l_i0*(1/La+rr);
  end
  
end
