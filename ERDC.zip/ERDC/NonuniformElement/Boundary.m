function [Up,idxf]=Boundary(N,X,X0)%Tim
% Up is displacements vector with constraint DOFs and idxf is idx of free DOFs
% postion
  BC=[dof_i(1,1) X0(1,1)
      dof_i(1,2) X0(2,1)
      dof_i(1,3) X0(3,1)
      dof_i(1,4) 0
      dof_i(2,1) X0(1,2)
      dof_i(2,2) X0(2,2)
      dof_i(2,3) X0(3,2)];
%position to displacement  
  BC(:,2)=BC(:,2)-X(BC(:,1));
  [Up,idxf]=Form_up(N,BC);
end
function [Up,idxf]=Form_up(N,bc)
Up=zeros(4*N+3,1);
Up(bc(:,1))=bc(:,2);
idxf=1:4*N+3;
idxf(bc(:,1))=[];
end
