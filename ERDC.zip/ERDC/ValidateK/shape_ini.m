function [X,tip,d1ip,kap_i,tau_i,li]=shape_ini(N,li0)
  pnt=[0 exp(1i*pi/6*[0 1 2 3]).*[0.5 1 1 0.5]];
  for k=2:5
      pnt(k)=pnt(k)+pnt(k-1);
  end
  
  zz=real(pnt);
  yy=imag(pnt)*sqrt(2)/2;
  xx=imag(pnt)*sqrt(2)/2;
  
  X=[xx;yy;zz];

  lli=zeros(1,N);
  li=lli;
  tip=zeros(3,N);
  d1ip=zeros(3,N);

  for ii=1:N
    dX=X(:,ii+1)-X(:,ii);
    lli(ii)=sqrt(dot(dX,dX));
    tip(:,ii)=dX/lli(ii);
    li(ii)=lli(ii)/li0;
  end
  li(1)=1;
  li(4)=1;
  theta=0*X(1,:);
  X=[X;theta];
  X=X(:);
  X(end)=[];
  
  d1ip(:,1)=[1;0;0];
  tau_i=-pi/6*ones(1,N+1);
  kap_i=zeros(3,N+1);
  
  for ii=2:N
      d1ip(:,ii)=para_base(tip(:,ii-1),tip(:,ii),d1ip(:,ii-1));
      d1ip(:,ii)=rotation(tip(:,ii),tau_i(ii)*li0,d1ip(:,ii));
      d1ip(:,ii)=d1ip(:,ii)/norm(d1ip(:,ii));
  end
  
  for ii=2:N  
    kap_i(:,ii)=2*cross(tip(:,ii-1),tip(:,ii))/(1+dot(tip(:,ii-1),tip(:,ii)))/li0;
  end

end