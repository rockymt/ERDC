clear all
global EI1 EI2 GIp EA;

N=4;

p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;
EI1=1;
EI2=1;
GIp=1;
EA=12;

[li0,kap1i_0,kap2i_0,taui_0]=shape_free(N);
[X,ti,d1i,kap_i,tau_i,li]=shape_ini(N,li0);

figure(1);
NN=N;
plot3(X(dof_i(1:NN+1,1)),X(dof_i(1:NN+1,2)),X(dof_i(1:NN+1,3)),'r-*');
hold on;
xxm=(X(dof_i(1:NN,1))+X(dof_i(2:NN+1,1)))/2;
yym=(X(dof_i(1:NN,2))+X(dof_i(2:NN+1,2)))/2;
zzm=(X(dof_i(1:NN,3))+X(dof_i(2:NN+1,3)))/2;
quiver3(xxm',yym',zzm',d1i(1,1:NN),d1i(2,1:NN),d1i(3,1:NN),.2,'-b');
xlabel('x');
ylabel('y');
zlabel('z');
axis equal;
hold off;

eeps=1e-6;
[F_int, K]=Force_int_K(N,ti,d1i,li,kap1i_0,kap2i_0,taui_0,li0,p,q,r);

U=eye(19)*eeps;
K_t=K*0;
for k=1:19
    X_t=X+U(:,k);
    [ti_t, d1i_t,li_t]=Update_everything(N,X_t,U(:,k),ti,d1i,li0);
    %     [F_int_t, K_t_t]=Force_int_K(N,ti_t,d1i_t,li_t,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
    [F_int_t]=Force_int(N,ti_t,d1i_t,li_t,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
    K_t(:,k)=(F_int_t-F_int)/eeps;
end
figure(2);
plot(1:19*19,K(:),'o',1:19*19,K_t(:),'+')
axis([-8,370,-60,60]);
xlabel('19(I-1)+J');
ylabel('Stiffness Components K_{IJ}');
legend('Analytically evaluated stiffness','Numerical estimation from perturbations to internal forces','Location','NorthOutside')
saveas(2,['Stiff.tiff']);
saveas(2,['Stiff.png']);
print -depsc Stiff.eps

