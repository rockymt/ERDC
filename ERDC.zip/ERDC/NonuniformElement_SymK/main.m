clear all

global EI1 EI2 GIp EA ToltalLen FlagSymK;
FlagSymK=1;

p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;
N=64;

EE=1;
RR=10;
EI1=EE*RR^4/12;
EI2=EE*RR^4/12;
GIp=(EI1+EI2)/2/(1+0);
ToltalLen=1000;
EA=EE*RR^2;

[li0,kap1i_0,kap2i_0,taui_0,X0]=shape_free(N,p,q,r);
[X,ti,d1i,li]=shape_ini(N,li0,X0);

Tim=0; MaxIter=50; Tol=1e-8; Steps=100; FinalTim=1.0; 
Dtim=FinalTim/Steps; NoSnap=4; SnapInc=Steps/NoSnap;

SnapXend=X(dof_i(N+1,1));SnapYend=X(dof_i(N+1,2));SnapZend=X(dof_i(N+1,3));
for kk=11:10+NoSnap
figure(kk)
plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'b--');
axis equal;
axis([-60 60 -80 40  0 500]);
set(gca,'xtick',[-60 -30 0 30 60]);
xticklabels({'-60','-30','0','30','60'})
set(gca,'ytick',[-80 -50 -20 10 40]);
yticklabels({'-80','-50','-20','10','40'})

xlabel('x');
ylabel('y');
zlabel('z');
%text(-30,30,0,'t=0')
hold on;
end
Snap=0;
for ii=1:Steps
    Tim=Tim+Dtim;
    [F_ext]= Force_ext(N,Tim);
    [U,idxf]=Boundary(N,X,X0);

    for jj=1:MaxIter
        [F_int, K]=Force_int_K(N,ti,d1i,li,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
        if jj==1
            RHS=F_ext-F_int-K*U;
        else
            RHS=F_ext-F_int;
        end

        [LK,UK]=lu(K(idxf,idxf));
        Uf=LK\RHS(idxf);
        Uf=UK\Uf;

        U(idxf)=Uf; 
        X=X+U;
        
        [ti, d1i,li]=Update_everything(N,X,U,ti,d1i,li0);
        if jj==1
%             error1=norm(RHS(idxf));
            error1=abs(dot(RHS(idxf),Uf));
%             error1=norm(URf);
        else
%             errormsg=norm(RHS(idxf))/error1; %Force criteria
            errormsg=abs(dot(RHS(idxf),Uf))/error1; %Energy criteria
%             errormsg=norm(URf)/error1; %displacement criteria
            if  errormsg<Tol
                break;
            end
        end
        U=U*0;
    end
    if jj==MaxIter
        ii
        jj
        error('Newton-Raphson iterations did not converge!');
    end
    if mod(ii,SnapInc)==0
        disp('=================================')
        disp([' Load step :',num2str(ii),'  Tim:',num2str(Tim)])
        disp('=================================')
        disp('  NR iter : L2-norm residual')
        disp(['  Iter ',num2str(jj),' RHS error:',num2str(errormsg)]);

        Snap=Snap+1;
        figure(10+Snap)
        plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'r-');


        psn=[X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3))];
        psnfile=['psn' num2str(Snap) '.txt'];
        save(psnfile,'psn','-ascii');
        
        SnapXend=[SnapXend X(dof_i(N+1,1))];
        SnapYend=[SnapYend X(dof_i(N+1,2))];
        SnapZend=[SnapZend X(dof_i(N+1,3))];
    end
end
figure(11)
text(-30,30,250,'t=0.25')
% saveas(11,['drawing11.tiff']);
% saveas(11,['drawing11.png']);
% saveas(11,['drawing11.eps'],'epsc');
print (11,"-r1200", "drawing11.tiff"); 

figure(12)
text(-30,30,350,'t=0.5')
% saveas(12,['drawing12.tiff']);
% saveas(12,['drawing12.png']);
% saveas(12,['drawing12.eps'],'epsc');
print (12,"-r1200", "drawing12.tiff"); 

figure(13)
text(-30,30,400,'t=0.75')
% saveas(13,['drawing13.tiff']);
% saveas(13,['drawing13.png']);
% saveas(13,['drawing13.eps'],'epsc');
print (13,"-r1200", "drawing13.tiff"); 

figure(14)
text(-30,30,400,'t=1')
% saveas(14,['drawing14.tiff']);
% saveas(14,['drawing14.png']);
% saveas(14,['drawing14.eps'],'epsc');
print (14,"-r1200", "drawing14.tiff"); 

