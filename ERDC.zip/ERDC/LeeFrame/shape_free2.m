function [li0,kap1i_0,kap2i_0,taui_0]=shape_free2(N)
  global ToltalLen;
  li0=ToltalLen/(N-1);
  kap1i_0=-0*ones(1,N+1);
  kap2i_0=-0*ones(1,N+1);
  taui_0=-0*ones(1,N+1);
end