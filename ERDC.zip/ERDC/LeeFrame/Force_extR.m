function [F_ext]=Force_extR(N,Tim)

    global TotalForce

    load=-Tim*TotalForce;
    F_ext=zeros(8*N,1);

    loadnum=1.5+(N-1)/5;
    loadfnum=floor(loadnum);
    loadbnum=loadfnum+1;
    loadf=load*(loadbnum-loadnum);
    loadb=load*(loadnum-loadfnum);

    F_ext(4*N-3+dof_i(loadfnum,2))=loadf;
    F_ext(4*N-3+dof_i(loadbnum,2))=loadb;

end