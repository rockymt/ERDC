clear all
global EI1 EI2 GIp EA ToltalLen;
p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;
N=96;

EE=1;
RR=10;
EI1=1*RR^4/12;
EI2=1*RR^4/12;
GIp=(EI1+EI2)/2/(1+0);
ToltalLen=1000;
EA=EE*RR^2;

[li0,kap1i_0,kap2i_0,taui_0]=shape_free(N);
[X,ti,d1i,li]=shape_ini(N,li0);

Tim=0; MaxIter=50; Tol=1e-8; Steps=500; FinalTim=1.0; 
Dtim=FinalTim/Steps; NoSnap=4; SnapInc=Steps/NoSnap;

figure(10)
plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'--');
axis equal;
axis([-200 600 -100 600 -200 50]);

xlabel('x')
ylabel('y')
zlabel('z')
hold on

figure(11)
plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'--');
axis equal;
axis([-200 600 -100 600 -200 50]);

xlabel('x')
ylabel('y')
zlabel('z')
hold on
figflag=1;
for ii=1:Steps
    Tim=Tim+Dtim;
    [F_extR]= Force_extR_suc(N,Tim);
    [UR,idxf]=BoundaryR(N);

    for jj=1:MaxIter
        [F_intR, KR]=Force_int_KR(N,ti,d1i,li,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
        if jj==1
            RHS=F_extR-F_intR-KR*UR;
        else
            RHS=F_extR-F_intR;
        end

        [LK,UK]=lu(KR(idxf,idxf));
        URf=LK\RHS(idxf);
        URf=UK\URf;

        UR(idxf)=URf; 
        U=DispR2N(UR,N,ti,li,li0);
        X=X+U;

        [ti, d1i,li]=Update_everything(N,X,U,ti,d1i,li0);

        if jj==1
%             error1=norm(RHS(idxf));
            error1=abs(dot(RHS(idxf),URf));
%             error1=norm(URf);
        else
%             errormsg=norm(RHS(idxf))/error1; %Force criteria
            errormsg=abs(dot(RHS(idxf),URf))/error1; %Energy criteria
%             errormsg=norm(URf)/error1; %displacement criteria
            if  errormsg<Tol
                break;
            end
        end

        UR=UR*0;
    end
    if jj==MaxIter
        ii
        jj
        error('Newton-Raphson iterations did not converge!');
    end
    if mod(ii,SnapInc)==0

        if figflag==1
            figure(10)
            plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'-');
            figflag=0;
            
        else
            figure(11)
            plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'-');
            figflag=1;
        end

        disp('=================================')
        disp([' Load step :',num2str(ii),'  Tim:',num2str(Tim)])
        disp('=================================')
        disp('  NR iter : L2-norm residual')
        disp(['  Iter ',num2str(jj),' RHS error:',num2str(errormsg)]);
        
    end
end
figure(10);
text(486,60,0,'t=0')
text(153,339,0,'t=0.25')
text(0,0,-30,'t=0.75')
figfile=['shape_suc_odd'];
% saveas(10,[figfile,'.tiff']);
print (10,"-r1000", [figfile,'.tiff']); 
saveas(10,[figfile,'.png']);
% saveas(10,[figfile,'.eps']);
print(10,[figfile,'.eps'],'-depsc');

figure(11);
text(486,60,0,'t=0')
text(-58,122,75,'t=0.5')
text(0,0,-50,'t=1.0')
figfile=['shape_suc_eve'];
% saveas(11,[figfile,'.tiff']);
print (11,"-r1000", [figfile,'.tiff']); 
% saveas(11,[figfile,'.png']);
% saveas(11,[figfile,'.eps']);
print(11,[figfile,'.eps'],'-depsc');
