function [F_ext]=Force_extR_suc(N,Tim)

global EI1 ToltalLen

Moment=[0; 0; (EI1*pi*4/ToltalLen)*(min([Tim*2 1]))];
Force=[0; 0; (EI1*pi*4/ToltalLen^2)]*(max([0 Tim*2-1]));
% Moment=[0; 0; (EI1*pi*4/ToltalLen)*Tim];
% Force=[0; 0; (EI1*pi*4/ToltalLen^2)]*Tim;
F_ext=zeros(4*N+3,1);
F_ext(end-5:end-3)=Moment;
F_ext(end-2:end)=Force;
end