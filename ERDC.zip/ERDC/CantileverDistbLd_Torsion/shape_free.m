function [li0,kap1i_0,kap2i_0,taui_0]=shape_free(N)
  global ToltalLen;
  
  mm=N/2;
  seg=1/(mm-0.5);
  s=ToltalLen/2*[0:seg:1-seg/2 1];
  lastSegLen=s(end)-s(end-1);
  s(end)=s(end)+lastSegLen;
  xx=[fliplr(-(s(2:end))) s]+ToltalLen/2;
  yy=0*xx;
  zz=yy;

  X0=[xx;yy;zz];
  ti0=zeros(3,N);


  for ii=1:N
    dX=X0(:,ii+1)-X0(:,ii);
    li0=sqrt(dot(dX,dX));
    ti0(:,ii)=dX/li0;
  end
%   li0=li0*2;

  theta=0*X0(1,:);
  X0=[X0;theta];
  X0=X0(:);

  kap1i_0=-0*ones(1,N+1);
  kap2i_0=-0*ones(1,N+1);
  taui_0=-0*ones(1,N+1);

end