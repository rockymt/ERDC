clear all
global EI1 EI2 GIp EA ToltalLen FlagSymK
FlagSymK = 0;
N=64;

p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;

EI1=1;
EI2=1;
GIp=(EI1+EI2)/(1+0.3)/2;
ToltalLen=1;
BB=1e-2; HH=BB;%
EE=12E8;
EA=EE*BB*HH;

[li0,kap1i_0,kap2i_0,taui_0]=shape_free(N);
[X,ti,d1i,li]=shape_ini(N,li0);
X0=X;

Tim=0; MaxIter=50; Tol=1e-8; Steps=20; FinalTim=1.0;
Dtim=FinalTim/Steps; NoSnap=4; SnapInc=Steps/NoSnap;

figure(10)
plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'--');
axis equal;

xlabel('x')
ylabel('y')
zlabel('z')
hold on

for ii=1:Steps
    Tim=Tim+Dtim;
    
    [F_ext]= Force_ext(N,Tim,li0);
    
    [U,idxf]=Boundary(N,X,X0);
    
    for jj=1:MaxIter
        [F_int, K]=Force_int_K(N,ti,d1i,li,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
        if jj==1
            RHS=F_ext-F_int-K*U;
        else
            RHS=F_ext-F_int;
        end

        [LK,UK]=lu(K(idxf,idxf));
        Uf=LK\RHS(idxf);
        Uf=UK\Uf;
        
        U(idxf)=Uf;
        X=X+U;
        
        [ti, d1i,li]=Update_everything(N,X,U,ti,d1i,li0);
        if jj==1
            %             error1=norm(RHS(idxf));
            error1=abs(dot(RHS(idxf),Uf));
            %             error1=norm(Uf);
        else
            %             errormsg=norm(RHS(idxf))/error1; %Force criteria
            errormsg=abs(dot(RHS(idxf),Uf))/error1; %Energy criteria
            %             errormsg=norm(Uf)/error1; %displacement criteria
            %        disp(['  Iter ',num2str(jj),' RHS error:',num2str(errormsg)]);
            if  errormsg<Tol
                break;
            end
        end
        
        U=U*0;
    end
    if jj==MaxIter
        ii
        jj
        error('Newton-Raphson iterations did not converge!');
    end
    if mod(ii,SnapInc)==0
        disp('=================================')
        disp([' Load step :',num2str(ii),'  Tim:',num2str(Tim)])
        disp('=================================')
        disp('  NR iter : L2-norm residual')
        disp(['  Iter ',num2str(jj),' RHS error:',num2str(errormsg)]);
        figure(10)
        plot3(X(dof_i(1:N+1,1)),X(dof_i(1:N+1,2)),X(dof_i(1:N+1,3)),'-');
    end
end
view([1 1 1])
text(0.8,0.1,0,'t=0')
text(0.8,0.4,0.2,'t=0.25')
text(0.6,0.5,0.4,'t=0.50')
text(0.4,0.5,0.5,'t=0.75')
text(0.4,0,0.6,'t=1.0')
figfile=['shape'];
%saveas(10,[figfile,'.tiff']);
print (10,"-r1000", [figfile,'.tiff']);
saveas(10,[figfile,'.png']);
% saveas(10,[figfile,'.eps']);
print(10,[figfile,'.eps'],'-depsc');


