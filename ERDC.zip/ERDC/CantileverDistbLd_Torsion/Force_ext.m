function [F_ext]=Force_ext(N,Tim,l_i0)

  f=Tim*20;
  Mt=-Tim*10;
  fvec=[0 f 0]';
  F_ext=zeros(4*N+3,1);
  uim=0.5*[eye(3) zeros(3,1) eye(3) zeros(3,1) zeros(3,3)];
  uip=0.5*[zeros(3,3) zeros(3,1) eye(3) zeros(3,1) eye(3)];
  u_i=[zeros(3,3) zeros(3,1) eye(3) zeros(3,1) zeros(3,3)];
  phii_p=[zeros(1,3) 0 zeros(1,3) 1 zeros(1,3)];
  phii_m=[zeros(1,3) 1 zeros(1,3) 0 zeros(1,3)];
  phi=[zeros(1,3) 0.5 zeros(1,3) 0.5 zeros(1,3)];
  for i=2:N
      dof11i=dof11(i,1:11);
      F_ext(dof11i)=F_ext(dof11i)+l_i0/6*(fvec'*uim+4*fvec'*u_i+fvec'*uip...
          +Mt*phii_m+4*Mt*phi+Mt*phii_p)';
  end

end