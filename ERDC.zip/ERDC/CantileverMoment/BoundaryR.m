function [URp,idxf]=BoundaryR(N)
% URp is displacements vector with constraint DOFs
% idxf is index of free DOFs
% BC(:,2) are the displacements in "R" function;
  BC=[1 0
      2 0
      3 0
      4 0
      5 0
      6 0];
  [URp,idxf]=Form_up(N,BC);
end
function [URp,idxf]=Form_up(N,bc)
URp=zeros(4*N+3,1);
URp(bc(:,1))=bc(:,2);
idxf=1:4*N+3;
idxf(bc(:,1))=[];
end
