function [li0,kap1i_0,kap2i_0,taui_0]=shape_free(N)
  
li0=1;
kap1i_0=-10*ones(1,N+1);
kap2i_0=-10*ones(1,N+1);
taui_0=-10*ones(1,N+1);
