clear all
global EI1 EI2 GIp EA;

N=5;

p=1.0/2;q=1.0/6; r=0;
% p=3.0/8;q=3.0/8; r=1.0/3;
% p=3.0/8;q=1.0/24; r=-1;
% p=0.25;q=0.25; r=0;
% p=1;q=0; r=0;
EI1=1;
EI2=1;
GIp=1;
EA=12;

[li0,kap1i_0,kap2i_0,taui_0]=shape_free(N);
[X,ti,d1i,kap_i,tau_i,li]=shape_ini(N,li0);

figure(1);
NN=N;
plot3(X(dof_i(1:NN+1,1)),X(dof_i(1:NN+1,2)),X(dof_i(1:NN+1,3)),'r-*');
hold on;
xxm=(X(dof_i(1:NN,1))+X(dof_i(2:NN+1,1)))/2;
yym=(X(dof_i(1:NN,2))+X(dof_i(2:NN+1,2)))/2;
zzm=(X(dof_i(1:NN,3))+X(dof_i(2:NN+1,3)))/2;
quiver3(xxm',yym',zzm',d1i(1,1:NN),d1i(2,1:NN),d1i(3,1:NN),.2,'-b');
xlabel('x');
ylabel('y');
zlabel('z');
axis equal;
hold off;

eeps=1e-6;
[F_intR, KR]=Force_int_KR(N,ti,d1i,li,kap1i_0,kap2i_0,taui_0,li0,p,q,r);

UR=eye(23)*eeps;
KR_t=KR*0;
for k=1:23
    U=DispR2N(UR(:,k),N,ti,li,li0);
    X_t=X+U;
    [ti_t, d1i_t,li_t]=Update_everything(N,X_t,U,ti,d1i,li0);
%     [F_intR_t, KR_t_t]=Force_int_KR(N,ti_t,d1i_t,li_t,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
    [F_intR_t]=Force_intR(N,ti_t,d1i_t,li_t,kap1i_0,kap2i_0,taui_0,li0,p,q,r);
    KR_t(:,k)=(F_intR_t-F_intR)/eeps;
end
figure(2);
plot(1:23*23,KR(:),'o',1:23*23,KR_t(:),'+')	
axis([-8,538,-20,30]);
xlabel('23(I-1)+J');
ylabel('Stiffness Components K^R_{IJ}');
legend('Analytically evaluated stiffness','Numerical estimation from perturbations to internal forces','Location','NorthOutside')
saveas(2,['Stiff.tiff']);
saveas(2,['Stiff.png']);
print -depsc Stiff.eps

